import React from 'react'
import "../../assets/css/index.css"

const Button = ({className, label,icon,onClick}) => {
  return (
    <div>
          <button className={className} onClick={onClick}>
          <i>{icon} </i> {label}
          </button>
    </div>
  )
}

export default Button