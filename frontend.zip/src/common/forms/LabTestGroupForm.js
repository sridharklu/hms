import CheckBox from "rc-checkbox";
import React,{useState} from "react";
import { useContext } from "react";
import { MdGroups, MdOutbound, MdOutlineAlternateEmail, MdOutlineAttachEmail, MdOutlineAttachMoney, 
  MdOutlineStorefront, MdOutlineThermostat, MdOutlineReceipt } from "react-icons/md";
import { LabTestGroupContext } from "../../containers/context/labTesGroupContext/LabTestGroupContext";
import Button from "../button/Button";
// import input from "../input/input";
import Label from "../label/Label";
import {useForm} from 'react-hook-form'
import { useNavigate } from "react-router-dom";
const LabTestGroupForm = () => {


  const navigate = useNavigate();
  const {register, handleSubmit}=useForm({

  });
  const { grouplabtestadded,cancelCourse }=useContext(LabTestGroupContext)


//  const data =(datas)=>grouplabtestadded(datas);
  return (


    <div>
           <div className="create-btn">
            <Button className="cancel-btn"   onClick={()=>cancelCourse(navigate("/labtestgroup"))}   label="Cancel" />
            <Button className="save-btn" label="Save invoice" icon={<MdOutlineReceipt  size={18}/>}
             onClick={()=>{ handleSubmit((d) => grouplabtestadded(d))(); cancelCourse(navigate("/labtestgroup"))} } ></Button>
            
            {/* <Button
              className="save-btn"
              label="Save invoice"
              // onClick={handleClick}
              icon={<MdOutlineReceipt  size={18}/>}
            /> */}
          </div>

          <h3>Test Group Details</h3>
      
       {/* <form onSubmit={handleSubmit((data))}>  */}
      <form>
      <div className="patient-form">
        <div className="patient-container">
          
          <Label label="Group Code" />
          {/* <div className="create-field">
            <MdOutlineStorefront className="icon" size={20} />
            <input
              // onChange={(e) => { updateGroupCode(e.target.value) }}
             // value={groupCode} 
              {...register('groupCode')}
              className="normal-field"
            />
          </div> */}
        </div>

        <div className="patient-container">
          <Label label="Group Name" />
          <div className="create-field">
            <MdOutlineStorefront className="icon" size={20} />
            <input
              // onChange={(e) => { updateGroupName(e.target.value) }}
              // value={groupName}
              {...register('testGroupName')}
              className="larger-field"
            />
          </div>
        </div>
      </div>
      <div className="patient-form">
        <div className="patient-container">
          <Label label="Parent Group Name" />
          <div className="create-field">
            <MdOutlineStorefront className="icon" size={20} />
            <input
              // onChange={(e) => { updateParent(e.target.value) }}
              // value={parentName}
              {...register('parentName')}
              className="normal-field"
            />
          </div>
        </div>

        <div className="patient-container">
          <Label label="Department Name" />
          <div className="create-field">
            <MdOutlineStorefront className="icon" size={20} />
            <input
              // onChange={(e) => { updteDepartmentName(e.target.value) }}
              // value={departmentName}
              {...register('departmentName')}
              className="normal-field"
            />
          </div>
        </div>

        <div className="patient-container">
          <Label label="rate" />
          <div className="create-field">
            <MdOutlineAttachMoney className="icon" size={20} />
            <input
              // onChange={(e) => { updteRate(e.target.value) }}
              // value={rate}
              {...register('rate')}
              className="normal-field"

            />
          </div>
        </div>
        <div className="patient-container">
          <Label label="Display Order" />
          <div className="create-field">
            <MdOutlineThermostat className="icon" size={20} />
            <input
              // onChange={(e) => { updteOrder(e.target.value) }}
              // value={order}
              {...register('order')}
              className="normal-field"
            />
          </div>
        </div>
      </div>

      <div className="patient-form">
        <div className="patient-container">

          <div className="create-field check">
            <div className="icon">
              <input type='checkbox' {...register('testDepartment')} ></input>
            </div>
            <input
              // onChange={(e) => { updteTestDepartment(e.target.value) }}
              // value={testDepartment}
           
              
              className="normal-field"

              placeholder="Test Of Same Department"

            />
          </div>
        </div>

        <div className="patient-container">

          <div className="create-field check">
            <div className="icon">
              <input type={'checkbox'}  {...register('print')}></input>
            </div>
            <input
              // onChange={(e) => { updtePrint(e.target.value) }}
              // value={print}
              // {...register('print')}
              className="normal-field"

              placeholder="Print select Test only"
            />
          </div>
        </div>

        <div className="patient-container">
          <div className="create-field check">
            <div className="icon">
              <input type={'checkbox'}   {...register('printDetails')}></input>
            </div>
            <input
              // onChange={(e) => { updtePrintDetails(e.target.value) }}
              // value={printDetails}
            
              className="normal-field"
              placeholder="Print Details"
            />
          </div>
        </div>
        <div className="patient-container">

          <div className="create-field check">
            <div className="icon">
              <input type={'checkbox'}   {...register('displayonTop')}></input>
            </div>
            <input
              // onChange={(e) => { updteDisplayTop(e.target.value) }}
              // value={displayTop}
            
              className="normal-field"
              placeholder="Display on Top"
              name="psw"
            />
          </div>
        </div>
      </div>

      <div className="patient-form">
        <div className="patient-container endCheck">

          <div className="create-field">
            <div className="icon">
              <input type={'checkbox'}   {...register('skipName')}></input>
            </div>
            <input
              // onChange={(e) => { updteSkipName(e.target.value) }}
              // value={skipName}
            
              className="larger-field"
              placeholder="Skip Group Naming in Printing"
              name="psw"
            />
          </div>
        </div>
     
        <div className="patient-container">
          <Label label="Group Condition" />
          <div className="create-field">
            <p className="icon">@@</p>

            <input
              // onChange={(e) => { updteGroupCondotion(e.target.value) }}
              // value={groupCondition}
              {...register('groupCondition')}
              className="larger-field"

            />
          </div>
        </div>
      </div>
      <div className="patient-form">
        <div className="patient-container">

          <div className="create-field check">
            {/* <div className="icon">
              
            </div> */}
            <input
              // onChange={(e) => { updteTestDepartment(e.target.value) }}
              // value={testDepartment}
              type='text'
              
              {...register('testCode')}
              
              className="normal-field"

              placeholder="Test Of Same Department"

            />
          </div>
        </div>

     

       
      
      </div>
      {/* <input type="submit" /> */}
      </form>
    </div>
  );
};

export default LabTestGroupForm;
