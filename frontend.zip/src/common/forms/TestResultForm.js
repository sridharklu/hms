// import React from 'react'
// import { MdOutlineArrowForward, MdOutlineMenuBook, MdPrint } from 'react-icons/md'
// import Button from '../button/Button'
// import Input from '../input/Input'

// const TestResultForm = () => {
//   return (
//     <div>
    
//     {/** test details */}
//     <div className="patient-testdetails">
//       <div className="patient-generaldetails">
//         <p>Patient name</p>
//         <h5>Mr.Naveen</h5>
//       </div>
//       <div className="patient-generaldetails">
//         <p>code</p>
//         <h5>108</h5>
//       </div>
//       <div className="patient-generaldetails">
//         <p>Age</p>
//         <h5>34 years</h5>
//       </div>
//       <div className="patient-generaldetails">
//         <p>Gender</p>
//         <h5>Male</h5>
//       </div>
//       <div className="patient-generaldetails">
//         <p>Phone no</p>
//         <h5>9876543210</h5>
//       </div>
//     </div>

//     <div className="test-orderdetails">
//       <div className="test-details">
//         <h5>Test Details</h5>
//       </div>



//       <div className="test-report">
//         <div className="order-test">
//           <div className="order-name">
//             <p>Test Name </p>
//             <h4>81</h4>
//           </div>
//           <div className="order-name">
//             <p>Test/Test Group Name</p>
//             <h4>Mr.Naveen</h4>
//           </div>
//         </div>
//         <div className="order-test">
          
//           <div className="order-name">
//             <p>Patient Name</p>
//             <Input type="text" />
//           </div>
//           <div className="order-name">
//             <p>Patient Name</p>
//             <h4>Mr.Naveen</h4>
//           </div>
//         </div>
//       </div>
      
//       <div className="group-btn">
//       <Button className="cancel-btn" label="Cancel"  />
//       <Button className="cancel-btn" label="Print" icon={<MdPrint size={13}/>} />
      
//         <Button className="save-btn" label="Save invoice"  icon={<MdOutlineMenuBook size={16}/>}/>
//       </div>
//     </div>
//   </div>
//   )
// }

// export default TestResultForm