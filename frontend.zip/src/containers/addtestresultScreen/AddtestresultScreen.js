import React,{useEffect,useContext} from 'react'
import Layout from '../../common/layout/Layout'
import { MdOutlineDoubleArrow,MdOutlineMessage, } from "react-icons/md";
import {CgSandClock} from "react-icons/cg";
import { Link } from 'react-router-dom';
import Button from '../../common/button/Button'
import "../../assets/css/index.css";
import { Table } from 'react-bootstrap';
import Input from '../../common/input/Input';
import axios from 'axios';
import { GlobalVariable } from '../../common/baseUrl/baseUrl';
import { AddtestresultContext } from '../context/addtestresultContext/AddtestresultContext';
import {OrderContext} from '../context/orderContext/OrderContext';
import { useNavigate } from 'react-router-dom';

const AddtestresultScreen = () => {
  const navigate = useNavigate();

  const {orders, updateOrders,saveTestresult,updatedetestResult,testResult} = useContext(AddtestresultContext)
  const {SinglePatients}= useContext(OrderContext)

   console.log(SinglePatients);

 

  // useEffect(() => {
  //   axios.get(`${GlobalVariable.MIDDLEWARE_API_URL}/orders`,
  //     { headers: { "token": localStorage.getItem("token") } })
  //     .then((res) => {
  //        //console.log(res.data.data)
  //         updateOrders(res.data.data)
  //       //console.log(res.data.data, "res data")
  //     })
  //     .catch((err) => {
  //       console.log(err)
  //     })

  // }, [])
  return (
    <Layout>
     <div >
     <div className="create-patient">
      <div className="create-topheader">
        <div className="create-navigate">
        <p className="navigateLable">TestResult</p>
          <MdOutlineDoubleArrow />
          <p>Edit</p>
        </div>
        
        <div className="create-btn">
          <Button className="cancel-btn" 
          
          onClick={()=>{window.location =  "http://localhost:3000/order"; }} 
      
          label="Cancel" />
          <Button
            className="save-btn"
            label="Save Result"
            onClick={ ()=>{saveTestresult(SinglePatients, navigate("/order")) }}
            icon={<CgSandClock size={18} />}
          />
        </div>
        
      </div>
    </div>
    <div className='orderdetail'>
        <p>OrderCode:<span>{SinglePatients.orderCode}</span></p>
        <p>OrderDate:<span>{SinglePatients.orderDate}</span></p>

     </div>

          <div className='card-container'>
                <table>
                    <tr>
                        <td>Patient Name<br/> <b><span>{SinglePatients.patientName}</span></b></td>
                        <td>Age <br/><b><span>{SinglePatients.patientAge}</span></b></td>
                        <td>Gender<br/><b><span>{SinglePatients.patientGender}</span></b></td>
                        <td>Phone No <br/><b><span>{SinglePatients.patientPhone}</span></b></td>
                        <td>Refferd By<br/><b><span>{SinglePatients.referredBy}</span></b></td>
                        <td>Patient type<br/><b><span>Lab</span></b></td>
                    </tr>

                    </table>

          </div>
          

        
        <div className='testresult-card'>
        <div className="card">
            <div className="card-header">
              TestResult
         </div>
        <div className="card-body">
          <p><input type="checkbox"/><span>Select All Test</span></p>  
            <div>
            <table className="table table-bordered">
          
  
                    <thead>
                        <tr>
                        <th scope="col" style={{width: "50%"}} >Test Name</th>
                        <th scope="col">Result</th>
                        <th scope="col">Units</th>
                        <th scope="col">Normal Ranges</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        ANTIBIOTIC SUSCEPTIBILITY TESTING (AST)
                        
                        </tr>
                        <tr>
                        <td> <p><input type="checkbox"/><span>{SinglePatients.testName}</span></p> </td>
                        <td><input type="text"  onChange={(e) => updatedetestResult(e.target.value)}
                         value={testResult}/></td>
                        <td></td>
                        <td></td>
                        </tr>
                        {/* <tr>ENDOCRINOLOGY</tr>
                      <tr>
                        <td><p><input type="checkbox"/><span>VITAMIN D 3 [25 oH- CHOLE]- SERUM</span></p></td>
                        {/* <td colspan="2">Larry the Bird</td> 
                        <td><input type="text"/></td>
                        <td>ng/ml</td>
                        <td>Deficiency :20 insufficiency: 20-30 sufficiency:30-100 Toxicity:100</td>
                        <tr>
                        <tr>
                            BIOCHEMISTRY
                         </tr>
                        <tr>
                            LIPID PROFILE
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>ACTH</span></p></td>
                          
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>Cholesterol-Total</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>HDL Cholesterol</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>Triglyceride (TGL)</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>LDL Cholesterol</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>VLDL Cholesterol</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><p><input type="checkbox"/><span>Total Chol / HDL Ratio</span></p></td>
                            <td><input type="text"/></td>
                            <td>mg/dl</td>
                            <td></td>
                        </tr>   */}
                    </tbody>
                    </table>
            </div>
            
        </div>
       </div>

        </div>
      
    </div>
    </Layout>

  )
}

export default AddtestresultScreen
