import { createContext, useState } from "react";
import axios from "axios";
import { GlobalVariable } from "../../../common/baseUrl/baseUrl";
import { Navigate } from "react-router-dom";

export const AddtestresultContext = createContext({})

export const AddtestresultContextProvider = ({ children }) => {

   const[testResult, settestResult] =useState(0)
   

      
   const updatedetestResult= (params)=>{
    settestResult(params)
   }

const saveTestresult = (SinglePatients) => {

    let testResultData={

        OrderCode: SinglePatients.orderCode,
        PatientCode: SinglePatients.patientCode,
        patientName: SinglePatients.patientName,
        patientAge: SinglePatients.patientAge,
        billAmount: SinglePatients.billAmount,
        totalAmount: SinglePatients.totalAmount,
        paidAmount: SinglePatients.paidAmount,
        testName: SinglePatients.testName,
        testCode: SinglePatients.testCode,
        testResult:testResult

        
        };

        let testResultstatusData ={
        
            find: {
                "orderCode": SinglePatients.orderCode,
            },
            update: {
                "status": true
            }
        };
    
        axios.post(`${GlobalVariable.MIDDLEWARE_API_URL}/testresult/add-testresult`,testResultData, )
       
        .then((res) => {
            console.log(res.data);
            
            // window.location.reload()
            // Navigate("/order")
        })
        .catch((err) => {
            console.log(err);
        })


        axios.put(`${GlobalVariable.MIDDLEWARE_API_URL}/orders/update-status`,
        testResultstatusData )
        .then((res)=>{
            console.log(res.data);
        }).catch((err)=>{
            console.log(err);
        })
}
   



    
    
 



    return (
        <AddtestresultContext.Provider
            value={{
                saveTestresult,
                updatedetestResult,testResult
                // orders,  updateOrders
            }}
            >{children}</AddtestresultContext.Provider>
    )
}