import { useState } from "react";
import { createContext } from "react";
import axios from "axios";
import {GlobalVariable} from '../../../common/baseUrl/baseUrl'
import { Navigate } from "react-router-dom";

export const LabTestGroupContext = createContext({})

export const LabTestGroupContextProvider = ({children}) => {
    const [groupCode,setGroupCode]= useState();
    const [groupName, setGroupName] = useState();
    const [parentName, setParant]= useState();
    const [departmentName,setDepartmentName]= useState();
    const [rate,setRate]= useState();
    const [order,setOrder]= useState();
    const [testDepartment, setTestDepartment]= useState();
    const [print,setPrint]= useState();
    const [printDetails, setPrintDetails]= useState();
    const [displayTop, setDisplayTop]= useState();
    const [skipName, setSkipName]= useState();
    const [groupCondition, setGroupCondotion]= useState();
    const [groupTests,setGroupTests] = useState([])
    const [isCheckAll, setIsCheckAll] = useState(false);
    const [isCheck, setIsCheck] = useState([]);

   
    const updateGroupCode= (params) => {
        setGroupCode(params)
    }
    const updateGroupName= (params) => {
        setGroupName(params)
    }
    const updateParent= (params) => {
        setParant(params)
    }
    const updteDepartmentName= (params) => {
        setDepartmentName(params)
    }
    const updteRate= (params) => {
        setRate(params)
    }
    const updteOrder= (params) => {
        setOrder(params)
    }
    const updteTestDepartment= (params) => {
        setTestDepartment(params)
    }
    const updtePrint= (params) => {
        setPrint(params)
    }
    const updtePrintDetails= (params) => {
        setPrintDetails(params)
    }
    const updteDisplayTop= (params) => {
        setDisplayTop(params)
    }
    const updteSkipName= (params) => {
        setSkipName(params)
    }
    const updteGroupCondiotion= (params) => {
        setGroupCondotion(params)
    }
    const updateGroupTests =(params) =>{
        setGroupTests(params)
    }
    
 const handleSelectAll = (e) => {
    setIsCheckAll(!isCheckAll);
    setIsCheck(groupTests.map((data) => data._id));
    if (isCheckAll) {
      setIsCheck([]);
    }
  };
   let selectCount = isCheck.length;


  const handleClick = (e) => {
    const { id, checked } = e.target;
    
    setIsCheck([...isCheck, id]);
    if (!checked) {
      setIsCheck(isCheck.filter((item) => item !== id));
    }
  };


const selectAllDelete = async()=>{

console.log(isCheck);
//  axios.all(isCheck.map((id) => axios.delete(`http://localhost:3001/api/patients/delete-patient/${id}`,{
//   headers:{"token": localStorage.getItem("token")  }
//     }))).then(  (data) => console.log(data));

}

const grouplabtestadded = async(datas)=>{
    console.log(datas);

    // datas.preventDefault();
  
            axios.post(`${GlobalVariable.MIDDLEWARE_API_URL}/grouptest/add-labgroup`,datas)
           
            .then((res) => {
                console.log(res.data);
                // navigate("/patient")
                // window.location.reload()
     
            })
            .catch((err) => {
                console.log(err);
            })
    
           
}


const cancelCourse = (id)=>{
    Navigate("/labtestgroup")
     document.getElementById(id).reset();
  }
    return(
        <LabTestGroupContext.Provider
        value={{
            updateGroupCode,groupCode,
            updateGroupName,groupName,
            updateParent,parentName,
            updteDepartmentName,departmentName,
            updteRate,rate,
            updteOrder,order,
            updteTestDepartment,testDepartment,
            updtePrint,print,
            updtePrintDetails,printDetails,
            updteDisplayTop,displayTop,
            updteSkipName,skipName,
            updteGroupCondiotion,groupCondition,
            updateGroupTests,groupTests,
            handleSelectAll,
            handleClick,selectCount,
            selectAllDelete,isCheck,isCheckAll,
            grouplabtestadded,cancelCourse

        }}>{children}</LabTestGroupContext.Provider>
    )
}