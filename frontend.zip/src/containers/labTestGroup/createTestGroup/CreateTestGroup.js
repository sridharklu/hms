import React from "react";
import { MdOutbound, MdOutlineArrowForward, MdOutlineDoubleArrow, MdOutlineReceipt } from "react-icons/md";
import Button from "../../../common/button/Button";
import Input from "../../../common/input/Input";
import Label from "../../../common/label/Label";
import "../../../assets/css/index.css";
import Layout from "../../../common/layout/Layout";
import LabTestGroupForm from "../../../common/forms/LabTestGroupForm";
import { Link, useNavigate } from "react-router-dom";

const CreateTestGroup = () => {
  const navigate = useNavigate();
  return (
    <Layout>
    
      <div className="create-patient">
        <div className="create-topheader">
          <div className="create-navigate">
            <Link to='/labtestgroup'>
          <p className="navigateLable">LabTestGroup</p>
          </Link>
            <MdOutlineDoubleArrow />
            <p>Create</p>
          </div>
     
          
        </div>
       
        <LabTestGroupForm />
      </div>
    </Layout>
   
  );
};
export default CreateTestGroup;
