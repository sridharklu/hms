import React from "react";
import Sample3 from "./Sample3";

const Sample1 = ({Name}) => {
    // console.log(Name);
    return (
        <div>
        <Sample3 Name = {Name}/>
        </div>
    )
}
export default Sample1