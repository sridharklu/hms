import React from "react";

const Sample2 =() => {
    return(
        <p>Sample2</p>
    )
}
export default Sample2