import React from "react";

const Sample3 = ({Name}) => {
    return (
        <div>
           {Name}
        </div>
    )
}
export default Sample3