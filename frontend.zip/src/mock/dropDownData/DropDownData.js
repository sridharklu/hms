 const DemoData = [
    {
        value:"Demo"
    },
    {
        value:"patients"
    },
    {
        value:"Doctor"
    }
]

export default DemoData;