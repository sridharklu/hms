export const options = ['Cash', 'Credit card', 'Depit card', 'upi'];
export default options;