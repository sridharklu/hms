const DepartmentListData = [

    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    {
        departmentcode: '1',
        departmentname: "Diwakar",
        remarks: '9092345134',
       
    },
    ]

  
  export const DepartmentListTitle  = [
   
    {title:"Department Code"},
    {title:"Department Name"},
    {title:"Remarks"},
  
   ]
   
   export default DepartmentListData;