const LabTestGroupData = [
    {
        GroupCode: '47',
        GroupName: "DEPOSITS",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '46',
        GroupName: "",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '54',
        GroupName: "DEFRENTIAL COUNT (DC)",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '36',
        GroupName: "ANTIBIOTIC SUSCEPTIBILITY TESTING (AST)",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '77',
        GroupName: "MICROSCOPIC (MS)",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '82',
        GroupName: "MICROSCOPIC (MS)",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '63',
        GroupName: "STOOL COMPLETE",
        Rate: '0',
        Delete: '',
    },
    {
        GroupCode: '40',
        GroupName: "MICROSCOPIC (MS)",
        Rate: '0',
        Delete: '',
    },

  ]
export const LabTestGroupTableHeader = [
    { title: "Group Code" },
    { title: "Group Name" },
    { title: "Rate" },
    { title: "" }
]
export default LabTestGroupData;