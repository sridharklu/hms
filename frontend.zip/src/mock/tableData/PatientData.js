const PatientsListData = [

    {
        patientCode: 'P0108',
        patientName: "Naveen",
        age: '34',
        gender: 'Male',
        patientBalance: '150',
        orders: '',
    },
    // {

    //     patientCode: 'P0107',
    //     patientName: "Yasar",
    //     age: '21',
    //     gender: 'Male',
    //     patientBalance: '15',
    //     orders: '',
    // },
    // {

    //     patientCode: 'P0106',
    //     patientName: "Arshath",
    //     age: '24',
    //     gender: 'Male',
    //     patientBalance: '10',
    //     orders: '',
    // },
    // {

    //     patientCode: 'P0105',
    //     patientName: "Ruby",
    //     age: '21',
    //     gender: 'Female',
    //     patientBalance: '0',
    //     orders: '',
    // },
    // {

    //     patientCode: 'P0104',
    //     patientName: "Rema",
    //     age: '18',
    //     gender: 'Female',
    //     patientBalance: '90',
    //     orders: '',
    // },
    // {

    //     patientCode: 'P0103',
    //     patientName: "Riyas",
    //     age: '30',
    //     gender: 'Male',
    //     patientBalance: '86',
    //     orders: '',
    // },
    ]


export const PatientsTableHeader = [
    { title: "Patient Code", },
    { title: "Patient Name" },
    { title: "Age" },
    { title: "Gender" },
    { title: "Patient Balance" },
    { title: "" }
]



export default PatientsListData;