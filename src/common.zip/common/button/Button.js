import React from 'react'
import "../../assets/css/index.css"

const Button = ({className, label,icon}) => {
  return (
    <div>
          <button className={className} >
          <i>{icon} </i> {label}
          </button>
    </div>
  )
}

export default Button