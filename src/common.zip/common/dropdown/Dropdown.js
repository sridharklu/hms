import React from 'react'
import "../../assets/css/index.css"

const Dropdown = ({className,placeholder,value,icon}) => {
  
  return (
    <div>
  <select className={className} placeholder={placeholder} icon={icon}>
  {value.map((data,index) => ( 
    <option value={data.value}>{data.value}</option>
    ))}
  </select>
        </div>
  )
}

export default Dropdown