import React from "react";
import "../../assets/css/header.css"
import { DemoData } from "../../mock/dropDownData/DropDownData";
import Dropdown from "../dropdown/Dropdown";
import Input from "../input/Input";
import {MdOutlinePerson, MdPlusOne} from "react-icons/md"
import Button from "../button/Button";

const Header = () => {
  return (
    <div class="flex-container">
      <div class="flex-item-left">
        <div className="inputContainer">
        <Button className="add-icon" icon={<MdPlusOne/>}/>
          <Input className="search" placeholder=" Search Patients..." type="text" />
        </div>
      </div>
      <div className="flex-item-right">
    <MdOutlinePerson size={20} />
        <Dropdown className="input-general" placeholder="SMS" value={DemoData} />
      </div>
    </div>
  );
};

export default Header;
