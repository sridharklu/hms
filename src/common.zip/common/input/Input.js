import React from "react";

const Input = ({ className, type, placeholder, label }) => {
  return (
    <div>
      <input
        className={className}
        type={type}
        placeholder={placeholder}
        label={label}
      />
    </div>
  );
};

export default Input;
