import React, { useState } from "react";
import "../../App.css";
import "../../assets/css/index.css"


import { MdCloudUpload, MdDashboard, MdHome, MdPaid, MdPeopleAlt, MdPerson, MdPersonAddAlt1, MdReceipt, MdTextsms } from "react-icons/md";

const SideBar = () => {
  const [isMenu, setIsMenu] = useState(false);

  const handleDrawer = () => {
    setIsMenu(true);
  };

  return (
    <div>
      <div className="navbutton" onClick={handleDrawer}>
        &#9776;
      </div>
      
      <div className="menu">
        {/* <div className="brand">
          <div className="brand-logo">
            <img className="company-logo" src={Image} />
          </div>
          <div className="brand-name">
            <h2>Alobin</h2>
            <p>Project Management</p>
          </div>
        </div> */}
        
          <ul className="sidebar">
          
          <li className="menu-item">
                <p><MdHome set="bulk" size={35} /> AloLab</p>
              </li>
             
              <li>
                <p><MdDashboard set="bulk" size={30} /> Dashboard</p>
              </li>
          
            
              <li>
                <p> <MdPersonAddAlt1 set="bulk"  size={30}/>registration</p>
              </li>
            
           
              <li>
                
                <p> <MdPeopleAlt set="bold" size={30} />Members</p>
              </li>
           
       
              <li>
               
                <p>  <MdReceipt set="bulk" size={30}/>Receipts</p>
              </li>
          
           
            <li>
              
              <p><MdPaid set="bold" size={30}/>Expenses</p>
            </li>
           
            
            <li>
              
              <p><MdTextsms set="bulk" size={30} />Meeting</p>
            </li>
          
         
            <li>
             
              <p> <MdCloudUpload set="bold"  size={30}/>Backup</p>
            </li>
          
          
            <li className="user">
              
              <p><MdPerson set="bold" size={30} />User</p>
            </li>
           
          </ul>
        </div>
     
      {/** ---- responsive sidebar ------  */}
      {isMenu && (
        <div className="nav-responsive">
          <ul >
          <li className="menu-item">
                <p><MdHome set="bulk" size={35} /> AloLab</p>
              </li>
              <li>
                <MdDashboard set="bulk" />
                <p>Dashboard</p>
              </li>
              <li>
                <MdPersonAddAlt1 set="bulk" />
                <p>registration</p>
              </li>
              <li>
                <MdPeopleAlt set="bold" />
                <p>Members</p>
              </li>
              <li>
                <MdReceipt set="bulk" />
                <p>Receipts</p>
              </li>
              <li>
                <MdPaid set="bold" />
                <p>Expenses</p>
              </li>
              <li>
                <MdTextsms set="bulk" />
                <p>Meeting</p>
              </li>
              <li>
                <MdCloudUpload set="bold" />
                <p>Backup</p>
              </li>
              <li className="logout">
                <MdPerson set="bold" />
                <p>User</p>
              </li>
            
          </ul>
        </div>
      )}
    </div>
  );
};

export default SideBar;
