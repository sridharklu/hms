import React from 'react'
import "../../../assets/css/index.css"
import DepartmentListData, { DepartmentListTitle } from '../../../mock/tableData/DepartmentListData'

const DepartmentTable = () => {
  return (
    <div className="list-table">
      <table>
        <tr className="table-hover-none">
          {DepartmentListTitle.map((data) => (
            <th>{data.title}</th>
          ))}
        </tr>
        {DepartmentListData.map((data, index) => (
          <tr>
            <td>{data.departmentcode}</td>
            <td>{data.departmentname}</td>
            <td>{data.remarks}</td>
          </tr>
        ))}
      </table>
    </div>
  )
}

export default DepartmentTable