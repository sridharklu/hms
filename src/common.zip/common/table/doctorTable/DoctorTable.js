import React from 'react'
import { MdCreate, MdOutlineDelete } from 'react-icons/md'
import DoctorsListData, { DoctorsTableHeader } from '../../../mock/tableData/DoctorsListData'
import "../../../assets/css/index.css"
const DoctorTable = () => {
  return (


<div className="tableContainer">
                    <table>
                        <tr>
                            <th className="createOrder"><input type="checkbox" /></th>
                            {DoctorsTableHeader.map((data) => (
                            <th>{data.title}</th>
                            ))}
                        </tr>
                        {DoctorsListData.map((data) => (
                        <tr>
                            <td className="createOrder"><input type="checkbox" /></td>
                            <td>{data.DoctorCode}</td>
                            <td>{data.DoctorName}</td>
                            <td>{data.SpecialistIn}</td>
                            <td>{data.Phone}</td>
                            <td>{data.Email}</td>
                            <td>{data.AppoinmentAmount}</td>
                            <td>{data.ScheduleDays}</td>
                            <td><MdOutlineDelete className="deleteIcon" /></td>
                        </tr>
                        ))}
                    </table>
                </div>
  )
}

export default DoctorTable