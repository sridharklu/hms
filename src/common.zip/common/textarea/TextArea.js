import React from "react";

const TextArea = ({ className, placeholder }) => {
  return (
    <div>
      <textarea className={className} placeholder={placeholder}></textarea>
    </div>
  );
};

export default TextArea;
