import React from "react";
import { MdOutlineDelete } from "react-icons/md";
import "../../assets/css/index.css";
import Button from "../button/Button";

const UpdateStatus = () => {
  return (
    <div>
      <div className="statusContainer">
        <h5>0 selected</h5>
        <Button className="update-box" label="Update Status" />
        <Button
          className="update-box"
          icon={<MdOutlineDelete />}
          label="Delete"
        />
      </div>
    </div>
  );
};

export default UpdateStatus;
